# Claim 2 rewrite review

You will review 481 original and rewritten text pairs. Each row asks 1 question. Your job is to decide whether the rewrite preserves every fact and relationship that could affect how the unchanged named consideration bears on the action.

You are comparing the 2 texts. You are not predicting whether a model would change its answer, and you are not deciding which moral answer is correct.

Complete the separate calibration before opening the study CSV. Work independently. Do not search for benchmark labels or model results, and do not discuss study rows with another reviewer until both submissions have been locked.

## Before the first row

1. Open `CALIBRATION.md` and answer every example before reading its expected answer.
2. Open your CSV in a spreadsheet editor using UTF-8 text encoding.
3. Freeze the header row and wrap the 3 text columns if your editor supports those options.
4. Do not sort the sheet or edit the source columns.
5. Stop after 60 rows or 60 minutes, whichever comes first. Take a break of at least 10 minutes before continuing.

The first 4 columns are frozen source fields. Fill only `preservation_judgment`, `diagnostic_flags`, and `short_explanation`.

## The judgment

Read the original text, the proposed rewrite, and the unchanged consideration. Then ask whether the rewrite preserves every fact and relationship that could reasonably affect whether that consideration supports or opposes the action.

| Response | Use it when |
| --- | --- |
| `PRESERVED` | Relevant actors, action, target, intent, causal facts, consequences, certainty, scope, moral stakes, specificity, and consideration target remain substantively fixed |
| `CHANGED` | At least 1 substantive difference could reasonably alter the `Supports` or `Opposes` judgment |
| `UNCERTAIN` | Ambiguity, awkward wording, or an incomplete comparison prevents a confident preservation judgment |

A smoother sentence can still be `PRESERVED`. A rewrite that adds a cause, resolves an ambiguity, changes certainty, changes who is affected, changes a deadline, or narrows the action is `CHANGED` or `UNCERTAIN`.

After `PRESERVED`, leave `diagnostic_flags` and `short_explanation` blank. After `CHANGED` or `UNCERTAIN`, select at least 1 allowed flag and write 1 short explanation.

Allowed flags include the following values.

- `ACTOR_ACTION_TARGET_INTENT`
- `FACTS_CERTAINTY_SCOPE_SPECIFICITY`
- `CONSEQUENCES_SEVERITY_MORAL_STAKES`
- `CONSIDERATION_TARGET_APPLICABILITY`
- `UNCLEAR_OR_MALFORMED`
- `OTHER`

Separate multiple flags with a semicolon. Describe the textual difference, not a possible model reaction.

## A complete row

A complete row has 1 preservation judgment. Diagnostic fields are blank after `PRESERVED`. Diagnostic fields contain flags and a short explanation after `CHANGED` or `UNCERTAIN`.

Pause if you catch yourself deciding whether the action is good or bad. Return to direct comparison of the texts. Do not invent a new response code.

## Finishing the package

Complete `METADATA_GUIDE.md` after the CSV. Keep the CSV filename, metadata filename, row order, review IDs, and source text unchanged. Return the CSV and metadata JSON together.
