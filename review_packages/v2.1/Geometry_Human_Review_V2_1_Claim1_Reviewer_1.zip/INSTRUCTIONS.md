# Claim 1 first-stage review

You will review 125 checkerboards. Each row contains 2 situations, 2 named considerations, and 4 stored relations. Your job is to make 6 judgments per row. You are judging whether the source examples are clear enough for the experiment. You are not judging whether either action is morally right.

Complete the separate calibration before opening the study CSV. Work independently. Do not search for benchmark labels or model results, and do not discuss study rows with another reviewer until both submissions have been locked.

## Before the first row

1. Open `CALIBRATION.md` and answer every example before reading its expected answer.
2. Open your CSV in a spreadsheet editor using UTF-8 text encoding.
3. Freeze the header row if your editor supports it.
4. Do not sort the sheet or edit any source column.
5. Stop after 60 rows or 60 minutes, whichever comes first. Take a break of at least 10 minutes before continuing.

The source columns end with `s2_B_relation`. Everything after that point is for your responses.

## The 4 cell judgments

Review the cells in this order.

1. Situation 1 with consideration A
2. Situation 1 with consideration B
3. Situation 2 with consideration A
4. Situation 2 with consideration B

For each cell, ask whether the stored `Supports` or `Opposes` relation is a clear and plausible reading under the stated facts and the ordinary meaning of the consideration.

| Response | Use it when |
| --- | --- |
| `CLEAR` | The situation is intelligible, the consideration applies, and the stored relation is a natural reading without a substantial competing interpretation |
| `AMBIGUOUS` | The consideration is relevant, but missing detail or competing readings prevent a clear relation judgment |
| `INVALID` | The situation is incoherent, the consideration does not apply, or the stored relation is not a plausible reading |

Enter the response in the matching clarity column. The prefixes `s1_A`, `s1_B`, `s2_A`, and `s2_B` identify the 4 cells.

After `CLEAR`, leave the matching failure flags and explanation blank. After `AMBIGUOUS` or `INVALID`, select at least 1 allowed flag and write 1 short explanation.

Allowed cell flags include the following values.

- `SITUATION_UNCLEAR`
- `CONSIDERATION_INAPPLICABLE`
- `COMPETING_RELATION_READINGS`
- `STORED_RELATION_IMPLAUSIBLE`
- `UNCERTAIN_REFERENCE`
- `MALFORMED_WORDING`
- `OTHER`

Separate multiple flags with a semicolon. Do not add facts that the situation does not state. Moral disagreement alone does not make a relation ambiguous.

## The 2 sense judgments

Compare consideration A across both situations, then compare consideration B across both situations. Ask whether the phrase keeps the same ordinary meaning.

| Response | Use it when |
| --- | --- |
| `STABLE` | The phrase keeps the same ordinary sense across both situations |
| `SHIFTED` | The phrase changes sense enough to alter the comparison |
| `UNCERTAIN` | The wording does not establish stable ordinary meaning |

Enter these responses in `A_sense` and `B_sense`.

After `STABLE`, leave the matching failure flags and explanation blank. After `SHIFTED` or `UNCERTAIN`, select at least 1 allowed flag and write 1 short explanation.

Allowed sense flags include the following values.

- `SHIFTED_MEANING`
- `UNCERTAIN_REFERENCE`
- `CHANGED_APPLICABILITY`
- `MALFORMED_WORDING`
- `OTHER`

## A complete row

A complete row has 4 clarity responses and 2 sense responses. Diagnostic fields are blank after `CLEAR` and `STABLE`. Diagnostic fields contain flags and a short explanation after every other response.

Pause if the column mapping feels unclear. Reopen this guide and the calibration before continuing. Do not invent a new response code.

## Finishing the package

Complete `METADATA_GUIDE.md` after the CSV. Keep the CSV filename, metadata filename, row order, review IDs, and source text unchanged. Return the CSV and metadata JSON together.
