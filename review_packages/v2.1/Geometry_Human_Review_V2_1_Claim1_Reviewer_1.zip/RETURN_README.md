# Return checklist

Use this checklist after completing the study sheet.

1. Confirm that every required judgment cell has a permitted response.
2. Confirm that diagnostics are blank after `CLEAR`, `STABLE`, or `PRESERVED`.
3. Confirm that every other response has at least 1 allowed flag and a short explanation.
4. Confirm that no source text, review ID, filename, column, or row order changed.
5. Complete the matching metadata JSON using `METADATA_GUIDE.md`.
6. Return the CSV and metadata JSON together.

Do not return the calibration file as a study submission. Do not combine answers from 2 reviewers. The study owner will run the locked validation command and will report any formatting failure without changing your answers.
