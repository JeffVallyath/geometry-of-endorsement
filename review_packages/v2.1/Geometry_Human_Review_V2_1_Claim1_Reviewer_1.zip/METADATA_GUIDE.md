# Reviewer metadata

Complete the metadata JSON after finishing the study CSV. Open it in a plain-text editor. Change only the empty reviewer fields listed below. Keep the freeze ID, task, reviewer slot, schema version, and instruction hash unchanged.

## Fields to complete

- `reviewer_pseudonym` receives the pseudonym assigned for this review.
- Each field beginning with `saw_` receives `false` only when you did not see the named information before or during review.
- `independent_completion_attestation` receives a short statement confirming independent completion.
- `session_log` receives 1 entry for every work block. Each entry records `block`, `rows`, and `minutes` as whole numbers.

Do not enter `false` when an exposure occurred. Stop and tell the study owner which information you saw. The affected review cannot enter the independent-consensus population without being reported correctly.

The session log should match the work limits in your instructions. A reviewer who completed 45 rows in 38 minutes records those 3 values for that block, then adds a new entry after the next work block.

## Before return

Confirm that the pseudonym is present, all 5 exposure fields contain a response, the attestation is present, and the session log contains every work block. Save valid JSON without renaming the file.

If the text editor reports invalid JSON, stop. Do not delete fixed fields to make the error disappear. Return the unmodified file to the study owner for help before the package is locked.
